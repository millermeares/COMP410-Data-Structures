package DiGraph_A5;
import gradingTools.comp410f19.assignment5.testcases.Assignment5Suite;

public class RunTests {
  public static void main(String[] args){ //runs Assignment 5 oracle tests
    Assignment5Suite.main(args);
  }
}
