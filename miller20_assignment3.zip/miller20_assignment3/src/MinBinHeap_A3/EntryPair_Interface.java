package MinBinHeap_A3;

public interface EntryPair_Interface {
  String getValue();
  int getPriority();
}