package Assignment0;
/**
 * COMP 410
 *
 * Make your class and its methods public!
 * Don't modify this file!
 * Begin by creating a class that implements this interface.
 *
*/

public interface HelloWorld_Interface {
  /*
    Interface: A HelloWorld will implement the following interface

    String say_it
      in: nothing
      return: String "hello world"
        
  String say_it_loud
    in: nothing
    return: String "HELLO WORLD"
  
  */


  String say_it();
  String say_it_loud();
}
